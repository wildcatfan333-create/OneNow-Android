# OneNow Push Notification Next Step

Web notifications inside a browser/WebView are not enough for reliable alerts when the
app is closed. The Android app should use Firebase Cloud Messaging.

Next implementation:

1. Create or connect a Firebase project.
2. Register Android package: com.onenowlive.app
3. Add google-services.json to app/
4. Add Firebase Messaging dependency.
5. Add a FirebaseMessagingService.
6. Save each signed-in user's FCM token to Supabase.
7. When OneNow creates a notification (message, reaction, comment, follow, World Moment,
   etc.), send an FCM push to that user's token.
8. Tapping the notification should open the correct OneNow screen/deep link.

Never place a Supabase service-role key in the Android client.
