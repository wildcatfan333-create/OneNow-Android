# OneNow Android v1

This is the first native Android shell for OneNow.

## What it already does

- Opens https://www.onenowlive.com inside the app
- Keeps OneNow links inside the app
- Opens outside links in the browser
- Supports JavaScript and local storage
- Supports gallery photo selection
- Supports taking a photo with the camera
- Supports location permission for the live map/post location
- Supports camera/microphone permission for web features
- Pull down to refresh
- Android back button navigates through OneNow first
- Requests notification permission on Android 13+
- Targets Android 16 / API 36 for current Google Play submission requirements

## Package name

com.onenowlive.app

Keep this package name once the app is published unless you intentionally want a different Play Store app.

## Important: push notifications

The app currently asks for Android notification permission, but true push notifications
while the app is closed require Firebase Cloud Messaging (FCM) or another native push
provider. The next step is to connect Firebase to this project and connect your OneNow
notification records / server logic to FCM.

Do not add a secret Supabase service-role key directly inside the Android app.

## Build without a computer

A GitHub Actions workflow is included at:

.github/workflows/android-debug.yml

If this project is uploaded to a GitHub repository, GitHub can build a test APK in the cloud.
Open the repository's Actions tab, run "Build OneNow Android APK", then download the
OneNow-debug-apk artifact.

## Google Play release

For Google Play, a signed Android App Bundle (.aab) is preferred. Release signing should
be added after the test APK is installed and verified.
